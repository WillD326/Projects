//
//  Pins.swift
//  WeFish
//
//  Created by Student on 12/14/20.
//  Copyright © 2020 Central. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class Pins {

}
