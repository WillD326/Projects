//
//  RegulationsViewContorller.swift
//  WeFish
//
//  Created by Student on 11/19/20.
//  Copyright © 2020 Central. All rights reserved.
//

import UIKit
import WebKit

class RegulationsViewController: UIViewController {
    @IBOutlet var regulationsView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let url = URL(string:"https://myfwc.com/about/rules-regulations/")!
        regulationsView.load(URLRequest(url: url))
    }
    
}
