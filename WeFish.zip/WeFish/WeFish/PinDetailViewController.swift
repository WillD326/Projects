//
//  PinDetailViewController.swift
//  WeFish
//
//  Created by Student on 12/14/20.
//  Copyright © 2020 Central. All rights reserved.
//

import UIKit

class PinDetailViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var titleField: UITextField!
    @IBOutlet var subtitleField: UITextField!
    
}
