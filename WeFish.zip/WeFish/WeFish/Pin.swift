//
//  Pin.swift
//  WeFish
//
//  Created by Student on 12/14/20.
//  Copyright © 2020 Central. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class Pin: Codable, Equatable {
    static func == (lhs: Pin, rhs: Pin) -> Bool {
        return lhs.long == rhs.long
            && lhs.lat == rhs.lat
            && lhs.title == rhs.title
            && lhs.subtitle == rhs.subtitle
    }
    
    
    var long: Double
    var lat: Double
    var title: String?
    var subtitle: String?
    
    init (title: String, subtitle: String, lat: Double, long: Double){
        self.title = title
        self.subtitle = subtitle
        self.lat = lat
        self.long = long
    }
    
    convenience init(random: Bool = false){
        if random {
        let titles = ["Current Location"]
        let randomTitle = "\(titles.randomElement()!)"
        let subtitles = ["You Are Here"]
        let randomSub = "\(subtitles.randomElement()!)"
        let latit = 28.09
        let longit = -82.52
        
        self.init(title: randomTitle, subtitle: randomSub, lat: latit, long: longit)
    }
        
    else{
    self.init(title: "", subtitle: "", lat: 0, long: 0)
    }
  }
}
