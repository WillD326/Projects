//
//  PinStore.swift
//  WeFish
//
//  Created by Student on 12/14/20.
//  Copyright © 2020 Central. All rights reserved.
//

import UIKit

class PinStore {
    
    var allPins = [Pin]()
    
    @discardableResult func
    createPin(isRandom: Bool) -> Pin {
        let newPin = Pin(random: isRandom)
        allPins.append(newPin)
        
        return newPin
    }
    
    func removePin(_ pin: Pin){
        if let index =
            allPins.firstIndex(of: pin){
            allPins.remove(at: index)
        }
    }
    
}
