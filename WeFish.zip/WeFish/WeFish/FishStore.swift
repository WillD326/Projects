//
//  FishStore.swift
//  WeFish
//
//  Created by Student on 10/30/20.
//  Copyright © 2020 Central. All rights reserved.
//

import UIKit

class FishStore {
    var allFish = [Fish]()
    init() {
        do{
            let data = try Data(contentsOf:  fishArchiveURL)
            let unarchiver = PropertyListDecoder()
            let fish = try unarchiver.decode([Fish].self, from: data)
            allFish = fish
        }
        catch{
            print("error reading in saved items: \(error)")
        }
        
    }
    
    let fishArchiveURL: URL = {
       let documentsDirectories = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentDirectory = documentsDirectories.first!
        return documentDirectory.appendingPathComponent("items.plist")
    }()
    
    
    @discardableResult func caughtFish(isRandom: Bool) -> Fish {
        let newFish = Fish(random: isRandom)
        allFish.append(newFish)
        return newFish
    }
    
    func removeFish(_ fish: Fish){
        if let index = allFish.firstIndex(of: fish){
            allFish.remove(at: index)
        }
    }
    func moveFish(from fromIndex: Int, to toIndex: Int){
        if fromIndex == toIndex{
            return
        }
        let movedFish = allFish[fromIndex]
        allFish.remove(at: fromIndex)
        allFish.insert(movedFish, at: toIndex)
    }
    
    @objc func saveChanges() -> Bool {
        print("Saving fish to: \(fishArchiveURL)")
        do{
        let encoder = PropertyListEncoder()
            let data = try encoder.encode(allFish)
            try data.write(to: fishArchiveURL, options: [.atomic])
            print("Saved all of the items")
            return true
        }
        catch let encodingError {
            print("Error encoding allFish: \(encodingError)")
             return false
        }
    }
    
    
}
