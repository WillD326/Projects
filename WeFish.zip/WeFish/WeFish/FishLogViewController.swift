//
//  FlogViewController.swift
//  WeFish
//
//  Created by Student on 10/30/20.
//  Copyright © 2020 Central. All rights reserved.
//

import UIKit

class FishLogViewController: UITableViewController, UISearchBarDelegate {
    @IBOutlet var searchBar: UISearchBar!
    var fishStore: FishStore!
    var imageStore: ImageStore!
    var filterFish: [Fish]!
    @IBOutlet var addButton: UIBarButtonItem!
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter
    }()
    
    func addNewItem() -> Int? {
        let newFish = fishStore.caughtFish(isRandom: false)
        if let index = fishStore.allFish.firstIndex(of: newFish){
            let indexPath = IndexPath(row: index, section: 0)
            tableView.insertRows(at: [indexPath], with: .automatic)
            return index
         }
        return nil
    }
    
    @IBAction func backgroundTapped(_ sender: UITapGestureRecognizer) {
        if searchBar.text == ""{
        view.endEditing(true)
        }
        else{
            view.endEditing(true)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        navigationItem.leftBarButtonItem = editButtonItem
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        tableView.rowHeight = 65
        
    }
    

    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchBar.text == ""{
            return fishStore.allFish.count
        }
        else{
        return filterFish.count
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "fishCell", for: indexPath) as! FishCell
        if searchBar.text == ""{
        let fish = fishStore.allFish[indexPath.row]
        cell.nameLabel.text = fish.name
        cell.lengthLabel.text = "\(fish.lengthInInches)in"
        cell.dateLabel.text = dateFormatter.string(from:fish.dateCuaght)
        cell.weightLabel.text = "\(fish.weightInPounds)lbs"
        }
        else{
            let fish = filterFish[indexPath.row]
            cell.nameLabel.text = fish.name
            cell.lengthLabel.text = "\(fish.lengthInInches)in"
            cell.dateLabel.text = dateFormatter.string(from:fish.dateCuaght)
            cell.weightLabel.text = "\(fish.weightInPounds)lbs"
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if searchBar.text == ""{
            let fish = fishStore.allFish[indexPath.row]
            fishStore.removeFish(fish)
            imageStore.deleteImage(forKey: fish.itemKey)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            }
            else{
                let fish = filterFish[indexPath.row]
                fishStore.removeFish(fish)
                filterFish.remove(at: indexPath.row)
                imageStore.deleteImage(forKey: fish.itemKey)
                tableView.deleteRows(at: [indexPath], with: .automatic)
            }
            
        }
    }
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        fishStore.moveFish(from: sourceIndexPath.row, to: destinationIndexPath.row)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        switch segue.identifier {
        case "showFish":
            if searchBar.text == "" {
            if let row = tableView.indexPathForSelectedRow?.row {
                let fish = fishStore.allFish[row]
                let fishDetailVC = segue.destination as! FishDetailViewController
                fishDetailVC.fish = fish
                fishDetailVC.imageStore = imageStore
             }
            }
            else{
                if let row = tableView.indexPathForSelectedRow?.row {
                    let fish = filterFish[row]
                    let fishDetailVC = segue.destination as! FishDetailViewController
                    fishDetailVC.fish = fish
                    fishDetailVC.imageStore = imageStore
                }
            }
        case "newFish":
            if let row = addNewItem() {
                let fish = fishStore.allFish[row]
                let fishDetailVC = segue.destination as! FishDetailViewController
                fishDetailVC.fish = fish
                fishDetailVC.imageStore = imageStore
                                
        }
        default:
            preconditionFailure("Unexpected segue identifier.")
        }
    }
    

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filterFish = []
        if searchText == ""{
            filterFish = fishStore.allFish
                addButton.isEnabled = true
        }
        else{
            addButton.isEnabled = false
        }
        for fish in fishStore.allFish {
            if fish.name.lowercased().contains(searchText.lowercased()){
                filterFish.append(fish)
            }
            
        }
    
        self.tableView.reloadData()
    }
}
