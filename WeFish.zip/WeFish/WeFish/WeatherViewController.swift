//
//  WeatherViewController.swift
//  WeFish
//
//  Created by Student on 11/19/20.
//  Copyright © 2020 Central. All rights reserved.
//
import UIKit
import CoreLocation
import MapKit

class WeatherViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    @IBOutlet var mapView: MKMapView!
    @IBOutlet var recenterButton: UIBarButtonItem!
    let locationManager = CLLocationManager()
    fileprivate lazy var  alertController: UIAlertController = {
    var alertView = UIAlertController(title: "Pin Title and Subtile", message: "We would like to give your pin a title and subtitle to allow the pins to have information" , preferredStyle: .alert)
        
        alertView.addAction(UIAlertAction(title: "Done", style: .default, handler: { (action) in print("submitted name:", self.titleField ?? "")
        }))
        alertView.addTextField( configurationHandler: {(textField) in self.titleField = textField})
        alertView.textFields?[0].placeholder = "Title"
        alertView.addTextField(configurationHandler: {(textField) in self.subField = textField})
        alertView.textFields?[1].placeholder = "Subtitle"
   
        return alertView
    }()
    var titleField: UITextField?
    var subField: UITextField?
    
    @IBAction func recenter() {
        centerMap()
    }
    @IBAction func changePinInfo() {
        present(alertController, animated: true)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        checkLocationServices()
    }
    
    override func loadView() {
        mapView = MKMapView()
        view = mapView
        let segmentedControl = UISegmentedControl(items: ["Standard", "Hybrid", "Satellite"])
        segmentedControl.backgroundColor = UIColor.white.withAlphaComponent(0.5)
        segmentedControl.selectedSegmentIndex = 0
        segmentedControl.addTarget(self, action: #selector(mapTypeChange(_:)), for: .valueChanged)
        
        segmentedControl.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(segmentedControl)
        
        let topConstraint = segmentedControl.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 8)
        let margins = view.layoutMarginsGuide
        let leadingConstraint = segmentedControl.leadingAnchor.constraint(equalTo: margins.leadingAnchor)
        let trailingConstraint = segmentedControl.trailingAnchor.constraint(equalTo: margins.trailingAnchor)
        topConstraint.isActive = true
        leadingConstraint.isActive = true
        trailingConstraint.isActive = true
  
    }
    
    @objc func mapTypeChange(_ segControl: UISegmentedControl){
        switch segControl.selectedSegmentIndex{
        case 0:
            mapView.mapType = .standard
        case 1:
            mapView.mapType = .hybrid
        case 2:
            mapView.mapType = .satellite
        default:
            break
        }
    }
 

    
    func setupLocationManager(){
        locationManager.delegate = self
        locationManager.desiredAccuracy =  kCLLocationAccuracyBest
    }
    
    func centerMap() {
        if let location = locationManager.location?.coordinate {
            let region = MKCoordinateRegion.init(center: location, latitudinalMeters: 10000, longitudinalMeters: 10000)
            mapView.setRegion(region, animated: true)
        }
    }
    @IBAction func backgroundTapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    @IBAction func addPin(){
        let pin = MKPointAnnotation()
        if let location = locationManager.location?.coordinate{
            let coords = CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)
        pin.coordinate = coords
            pin.title = titleField?.text
            pin.subtitle = subField?.text
        mapView.addAnnotation(pin)
        }
    }
    @IBAction func deletePin() {
        if mapView.selectedAnnotations.last == nil {
            let noPin = UIAlertController(title: "No Pin Selected", message: "A Pin must be selected to be deleted", preferredStyle: .alert)
            noPin.addAction(UIAlertAction(title: "Okay", style: .cancel, handler: nil))
            present(noPin, animated: true)
        }
        else{
        mapView.removeAnnotation(mapView.selectedAnnotations.last as! MKAnnotation)
        }

    }
    
        
    func alertLocationAccessNeeded() {
        let settingsAppURL = URL(string: UIApplication.openSettingsURLString)!
        let alert = UIAlertController(title: "Location must be turned on for the app to work", message: "I recommend you turn on the location to use the app", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Allow Access", style: .cancel, handler: {(alert) -> Void in UIApplication.shared.open(settingsAppURL, options: [:], completionHandler: nil)}))
        alert.addAction(UIAlertAction(title: "Deny", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else{return}
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let region = MKCoordinateRegion.init(center: center, latitudinalMeters: 10000, longitudinalMeters: 10000)
        mapView.setRegion(region, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        checkLocationAuthorization()
    }
    
    func checkLocationServices() {
        if CLLocationManager.locationServicesEnabled(){
            setupLocationManager()
            checkLocationAuthorization()
        }
        else{
            
        }
    }
        func checkLocationAuthorization() {
            switch CLLocationManager.authorizationStatus(){
            case .authorizedWhenInUse:
                mapView.showsUserLocation = true
                centerMap()
                locationManager.startUpdatingLocation()
                break
            case .denied:
                alertLocationAccessNeeded()
                break
            case .notDetermined:
                locationManager.requestWhenInUseAuthorization()
            case .restricted:
                alertLocationAccessNeeded()
                break
            case .authorizedAlways:
                break
            
            }
        }
        
        
    
}


