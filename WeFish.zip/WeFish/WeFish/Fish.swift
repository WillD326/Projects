//
//  Fish.swift
//  WeFish
//
//  Created by Student on 10/30/20.
//  Copyright © 2020 Central. All rights reserved.
//

import UIKit

class Fish: Equatable, Codable {
    var name: String
    var bait: String?
    var lengthInInches: Int
    var weightInPounds: Int
    let dateCuaght: Date
    let itemKey: String
    
    init(name: String, bait: String?, lengthInInches: Int, weightInPounds: Int){
        self.name = name
        self.bait = bait
        self.lengthInInches = lengthInInches
        self.weightInPounds = weightInPounds
        self.dateCuaght = Date()
        self.itemKey = UUID().uuidString
        
    }
    
    convenience init(random: Bool = false){
        if random{
            let names = ["Spanish Mackerel", "Black Tip Shark", "Flounder"]
            let baits = ["Shrimp", "Lures", "Pin Fish"]
            
            let randomName = "\(names.randomElement()!)"
            let randomBait = "\(baits.randomElement()!)"
            let randomLength = Int.random(in: 5..<100)
            let randomWeight = Int.random(in: 1..<100)
            
            self.init(name: randomName, bait: randomBait, lengthInInches: randomLength, weightInPounds: randomWeight)
        }
        else{
            self.init(name: "", bait: "", lengthInInches: 0, weightInPounds: 0)
        }
    }
    static func ==(lhs: Fish, rhs: Fish) -> Bool {
        return lhs.name == rhs.name
        && lhs.lengthInInches == rhs.lengthInInches
        && lhs.bait == rhs.bait
        && lhs.weightInPounds == rhs.weightInPounds
        && lhs.dateCuaght == rhs.dateCuaght
        
    }
    
}
