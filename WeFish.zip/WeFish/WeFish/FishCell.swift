//
//  FishCell.swift
//  WeFish
//
//  Created by Student on 11/15/20.
//  Copyright © 2020 Central. All rights reserved.
//

import UIKit

class FishCell: UITableViewCell {
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var lengthLabel: UILabel!
    @IBOutlet var weightLabel: UILabel!
    
}
