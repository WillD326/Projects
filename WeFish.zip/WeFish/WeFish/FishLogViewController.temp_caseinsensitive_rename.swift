//
//  FlogViewController.swift
//  WeFish
//
//  Created by Student on 10/30/20.
//  Copyright © 2020 Central. All rights reserved.
//

import UIKit

class FishLogViewController: UITableViewController {
    
}
